// =============================================================
// POST /api/webhook
// Riceve eventi Stripe e invia email via EmailJS REST API
// =============================================================

const Stripe = require("stripe");

// ---- Disabilita il body parsing di Vercel (serve il raw body per la firma) ----
module.exports.config = { api: { bodyParser: false } };

// ---- Legge il raw body ----
function getRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

// ---- Invia email via EmailJS REST API ----
async function sendEmailJS(templateParams) {
  const payload = {
    service_id:  process.env.EMAILJS_SERVICE_ID,
    template_id: process.env.EMAILJS_TEMPLATE_ID,
    user_id:     process.env.EMAILJS_PUBLIC_KEY,
    template_params: templateParams
  };

  const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`EmailJS error: ${response.status} — ${text}`);
  }

  return true;
}

// ---- Handler ----
module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const stripe         = new Stripe(process.env.STRIPE_SECRET_KEY);
  const webhookSecret  = process.env.STRIPE_WEBHOOK_SECRET;
  const rawBody        = await getRawBody(req);
  const signature      = req.headers["stripe-signature"];

  let event;

  // ---- Verifica firma Stripe ----
  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("[webhook] Signature verification failed:", err.message);
    return res.status(400).json({ error: "Invalid signature" });
  }

  // ---- Gestione evento ----
  if (event.type === "checkout.session.completed") {
    const session  = event.data.object;
    const metadata = session.metadata || {};

    console.log("[webhook] Checkout completed for:", metadata.name, metadata.email);

    // Parametri per il template EmailJS (stessi nomi usati nel template)
    const templateParams = {
      name:           metadata.name         || "-",
      phone:          metadata.phone        || "-",
      customer_email: metadata.email        || "-",
      service_type:   metadata.service_type || "-",
      route:          metadata.route        || "-",
      pax:            metadata.pax          || "-",
      date:           metadata.date         || "-",
      time:           metadata.time         || "-",
      flight:         metadata.flight       || "-",
      pickup:         metadata.pickup       || "-",
      dropoff:        metadata.dropoff      || "-",
      notes:          metadata.notes        || "-",
      total:          metadata.total ? "€" + metadata.total : "-",
      night_fee:      metadata.night_fee    || "-"
    };

    try {
      await sendEmailJS(templateParams);
      console.log("[webhook] Email inviata con successo.");
    } catch (err) {
      console.error("[webhook] Errore invio email:", err.message);
      // Non ritorniamo errore a Stripe — l'email fallita non deve bloccare il flusso
    }
  }

  // ---- Conferma ricezione a Stripe ----
  return res.status(200).json({ received: true });
};
